DELETE FROM `PayrollColumns`,`PayrollColumnTemplates`, `PayrollData`, `PayrollEmployees`, `PayslipTemplates`;
