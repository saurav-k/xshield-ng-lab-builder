Admin users of icehrm can find the access token under System->Settings.
IceHrm uses Bearer Authorization.
