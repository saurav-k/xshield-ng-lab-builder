<?php

namespace Classes\Pdf;

interface PdfBuilder
{
    public function createPdf();
}
