<?php

namespace Classes\Exception;

class GoogleSyncException extends \Exception
{

}
