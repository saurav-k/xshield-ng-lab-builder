<?php
namespace Classes\Exception;

class IceHttpException extends \Exception
{

}
