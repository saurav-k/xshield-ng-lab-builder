<?php

namespace Classes\Exception;

class UserTokenNotFoundException extends \Exception
{

}
