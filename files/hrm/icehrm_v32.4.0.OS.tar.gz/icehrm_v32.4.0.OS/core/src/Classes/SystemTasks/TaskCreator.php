<?php

namespace Classes\SystemTasks;

interface TaskCreator
{
    public function getTasksCreators();
}
