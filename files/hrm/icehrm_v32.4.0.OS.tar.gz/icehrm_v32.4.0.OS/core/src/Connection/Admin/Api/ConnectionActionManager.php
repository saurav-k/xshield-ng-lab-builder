<?php
namespace Connection\Admin\Api;

use Classes\SubActionManager;

class ConnectionActionManager extends SubActionManager
{

}
