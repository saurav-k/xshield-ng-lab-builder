<?php
header("Location:".CLIENT_BASE_URL."login.php?logout=1");
