<?php
putenv('ICE_CONFIG_FILE=../docker/development/config/config.php');
require './core/shell.php';